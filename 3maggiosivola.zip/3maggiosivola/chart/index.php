<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>
<?php include 'content.php'; ?>
<h1>Home</h1>
<div id="chartContainer"></div>

<?php

	include("funzioni.php");
	$conn = connect("ristorante");
	$data = array();
	$sql = "select count(data) as n, data from prenotazioni group by data";
	$result = $conn->query($sql);
	$i=0;
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()){
			$data[$i] = $row["data"];
			$n = $row["n"];
			$i++;
		}
	}
	
    $dataPoints = array(
        array("y" => $n, "label" => $data),
       
    );
?>

<script type="text/javascript">

    $(function () {
        var chart = new CanvasJS.Chart("chartContainer", {
            theme: "theme2",
            animationEnabled: true,
            title: {
                text: "Andamento delle prenotazioni"
            },
            data: [
            {
                type: "column",                
                dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
            }
            ]
        });
        chart.render();
    });
</script>

<?php include 'footer.php'; ?>