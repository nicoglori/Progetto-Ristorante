<html>
<head>
	<link href="../css/bootstrap.css" type="text/css" rel="stylesheet"/>
	<link href="../css/menu.css" type="text/css" rel="stylesheet"/>
	<title>Admin Panel</title>
	
</head>
<body>
<div class="jumbotron text-center">
<h3>Admin panel </h3>

</div>
<!-- Inserire ristoranti e luoghi -->


<div class="container">
	<div id="menu_sidebar">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="insertLuogo.php">Inserimento indirizzo</a></li>
			<li><a href="insertRisto.php">Inserimento ristorante</a></li>
			<li><a href="viewR.php" id="ricerca">Visualizza ristoranti</a></li>
			<li><a href="viewG.php">Visualizza grafici</a></li>
			<li><a href="../../phpmyadmin">DBMS</a></li>
		</ul>
	</div>
	<div id="risposta"></div>
</div>
</body>
</html>